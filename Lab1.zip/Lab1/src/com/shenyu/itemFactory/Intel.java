package com.shenyu.itemFactory;

import com.shenyu.factory.*;

public class Intel extends CPU{
	
	public Intel(String name, int coreNum, int price) {
		super(name, price, coreNum);
	}

}
