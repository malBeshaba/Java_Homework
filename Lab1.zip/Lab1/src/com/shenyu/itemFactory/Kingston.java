package com.shenyu.itemFactory;

import com.shenyu.factory.Memory;

public class Kingston extends Memory {
	
	public Kingston(String name, int price, int volume) {
		super(name, price, volume);
	}

}
