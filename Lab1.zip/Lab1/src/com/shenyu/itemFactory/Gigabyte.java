package com.shenyu.itemFactory;

import com.shenyu.factory.Mainboard;

public class Gigabyte extends Mainboard{
	
	public Gigabyte(String name, int price, int speed) {
		super(name, price, speed);
	}
}
