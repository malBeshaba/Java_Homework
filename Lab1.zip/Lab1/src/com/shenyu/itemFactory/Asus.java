package com.shenyu.itemFactory;

import com.shenyu.factory.Mainboard;

public class Asus extends Mainboard{
	
	public Asus(String name, int price, int speed) {
		super(name, price, speed);
	}

}
