package com.shenyu.itemFactory;

import com.shenyu.factory.HD;

public class WestDigitals extends HD {
	
	public WestDigitals(String name, int price, int volume) {
		super(name, price, volume);
	}

}
